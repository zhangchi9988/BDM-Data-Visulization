import matplotlib.pyplot as plt 
  
# heights of bars 
height = [10, 24, 36, 40, 5] 
  
# labels for bars 
names = ['one', 'two', 'three', 'four', 'five'] 
  
# plotting a bar chart
c1 =['red', 'green']
c2 =['b', 'g']

plt.bar(names, height, width=0.5, color=c2) 

# naming the x-axis 
plt.xlabel('x - axis') 
# naming the y-axis 
plt.ylabel('y - axis') 
# plot title 
plt.title('My bar chart!') 
  
# function to show the plot 
plt.show() 
