import matplotlib.pyplot as plt

#Create data for plotting
x_values = [5,6,3,7,2]
y_values = ["A", "B", "C", "D", "E"]

plt.bar(y_values, x_values, color = "green")
plt.show() 
