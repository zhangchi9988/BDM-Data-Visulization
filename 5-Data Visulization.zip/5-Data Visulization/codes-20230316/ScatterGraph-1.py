import matplotlib.pyplot as plt

#create data for plotting

x_values = [0,1,2,3,4,5]
y_values = [0,1,4,9,16,25]

#plt.scatter(x_values, y_values, s=30, color="blue")
plt.scatter(x_values, y_values, s=50, color="blue")
plt.show() 
