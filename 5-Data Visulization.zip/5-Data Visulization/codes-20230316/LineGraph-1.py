import matplotlib.pyplot as plt

#create data for plotting
x_values = [0, 1, 2, 3, 4, 5]
y_values = []
for i in x_values:
    y_values.append(i**2)

#the default graph style for plot is a line
plt.plot(x_values, y_values)

#display the graph
plt.show() 

